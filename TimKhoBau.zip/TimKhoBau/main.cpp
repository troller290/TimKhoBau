#include "Game.h"

int main()
{
	Game treasure_finding;
	treasure_finding.Nhap();
	treasure_finding.TimKhoBau();
	return 0;
}